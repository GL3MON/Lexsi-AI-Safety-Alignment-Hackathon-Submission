"""Verified scenario-bank loading; hidden routes never enter actor messages."""
import hashlib
import json
from collections import defaultdict
from functools import lru_cache
from tau2_grpo.rl_config import path

@lru_cache(maxsize=2)
def load_bank(directory):
    root=path(directory)
    manifest=json.loads((root/'manifest.json').read_text())
    if not manifest.get('complete') or manifest.get('accepted')!=3000:
        raise ValueError('Scenario bank is incomplete')
    for name,digest in manifest['files_sha256'].items():
        if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Scenario bank hash mismatch: '+name)
    rows={};pools={};worlds={}
    for split,expected in [('train',2400),('validation',300),('test',300)]:
        data=[json.loads(line) for line in (root/(split+'.jsonl')).read_text().splitlines()]
        if len(data)!=expected:raise ValueError('Incorrect split count')
        pools[split]=[r['id'] for r in data];worlds[split]={r['world_id'] for r in data}
        for r in data:
            if r['id'] in rows or r['split']!=split:raise ValueError('Duplicate/misplaced case')
            if r['max_actor_turns']>4 or r['max_reference_prompt_tokens']+192>8192:raise ValueError('Case exceeds short budget')
            rows[r['id']]=r
    if any(worlds[a]&worlds[b] for a,b in [('train','validation'),('train','test'),('validation','test')]):
        raise ValueError('Customer worlds overlap')
    return root,rows,pools,json.loads((root/'catalog.json').read_text())

def bank_task_ids(cfg,partition='rl'):
    _,_,pools,_=load_bank(cfg.scenario_bank)
    return list(pools['train' if partition=='rl' else partition])

def bank_environment(cfg,case_id):
    from tau2_grpo.short_scenario_bank import BankEnvironment
    root,rows,_,catalog=load_bank(cfg.scenario_bank);case=rows[case_id]
    if cfg.max_actions<case['max_actor_turns']:raise ValueError('Insufficient actor turn budget')
    if case['messages'][0]['content']!=path(cfg.system_prompt_file).read_text():raise ValueError('Bank system prompt differs')
    if (root/'chat_template.jinja').read_text()!=path(cfg.chat_template_file).read_text():raise ValueError('Bank template differs')
    world=json.loads((root/case['world_file']).read_text())
    return BankEnvironment(case,world,catalog)

CLARIFICATION_FAMILIES=('missing_identity','missing_first_name','missing_last_name','missing_zip','partial_first_name','partial_last_name','partial_zip','failed_email')

def clarification_order(cfg,ids,rng):
    _,rows,_,_=load_bank(cfg.scenario_bank);families=defaultdict(list)
    for cid in ids:families[rows[cid]['family']].append(cid)
    categories={'clarification':[k for k in sorted(families) if k in CLARIFICATION_FAMILIES], 'retention':[k for k in sorted(families) if k not in CLARIFICATION_FAMILIES]}
    if not all(categories.values()):raise ValueError('Clarification curriculum needs both categories')
    family_cycles={k:[] for k in categories};case_cycles={k:[] for k in families};result=[]
    for i in range(len(ids)):
        category='retention' if i%3==2 else 'clarification'
        if not family_cycles[category]:
            family_cycles[category]=list(categories[category]);rng.shuffle(family_cycles[category])
        family=family_cycles[category].pop()
        if not case_cycles[family]:
            case_cycles[family]=list(families[family]);rng.shuffle(case_cycles[family])
        result.append(case_cycles[family].pop())
    return result

def balanced_order(cfg,ids,rng):
    if cfg.bank_sampling=='clarification_mix':return clarification_order(cfg,ids,rng)
    _,rows,_,_=load_bank(cfg.scenario_bank);families=defaultdict(list)
    for case_id in ids:families[rows[case_id]['family']].append(case_id)
    keys=sorted(families)
    for group in families.values():rng.shuffle(group)
    result=[]
    while any(families.values()):
        rng.shuffle(keys)
        result.extend(families[key].pop() for key in keys if families[key])
    return result

def validation_cases(cfg):
    _,rows,pools,_=load_bank(cfg.scenario_bank);selected={}
    for case_id in sorted(pools['validation']):selected.setdefault(rows[case_id]['family'],case_id)
    return [selected[k] for k in sorted(selected)]
